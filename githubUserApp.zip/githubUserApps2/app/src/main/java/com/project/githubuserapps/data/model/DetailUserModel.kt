package com.project.githubuserapps.data.model

data class DetailUserModel(
    val login: String,
    val id: Int,
    val html_url: String,
    val avatar_url: String,
    val followers_url: String,
    val following_url: String,
    val location: String,
    val name: String,
    val following: Int,
    val followers: Int
)