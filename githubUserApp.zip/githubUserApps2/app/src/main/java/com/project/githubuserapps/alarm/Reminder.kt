package com.project.githubuserapps.alarm

data class Reminder(
    var isReminder: Boolean = false
)
