package com.project.githubuserapps.data.viewmodel

import android.content.Context
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.project.githubuserapps.data.api.ApiService
import com.project.githubuserapps.data.model.UserModel
import com.project.githubuserapps.data.model.UserResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel : ViewModel() {
    val listUsers = MutableLiveData<ArrayList<UserModel>>()

    fun setSearchUsers(query: String, context: Context) {
        ApiService.apiInstance
            .getSearchUsers(query)
            .enqueue(object : Callback<UserResponse> {
                override fun onResponse(
                    call: Call<UserResponse>,
                    response: Response<UserResponse>
                ) {
                    if (response.isSuccessful) {
                        listUsers.postValue(response.body()?.items)
                    }
                }

                override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                    Toast.makeText(context,t.message.toString(),Toast.LENGTH_SHORT).show()
                }
            })

    }

    fun getSearchUsers(): LiveData<ArrayList<UserModel>> {
        return listUsers
    }
}