package com.project.githubuserapps.fragment

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.project.githubuserapps.DetailUserActivity
import com.project.githubuserapps.R
import com.project.githubuserapps.adapter.UserAdapter
import com.project.githubuserapps.data.viewmodel.FollowersViewModel
import com.project.githubuserapps.data.viewmodel.FollowingViewModel
import com.project.githubuserapps.databinding.FragmentFollowBinding

class FollowFragment(position: Int, context: Context) : Fragment(R.layout.fragment_follow) {

    private var _binding: FragmentFollowBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: UserAdapter
    private lateinit var username: String
    private val fragmentPostion: Int?
    private val mContext: Context

    init {
        fragmentPostion = position
        mContext = context
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val args = arguments
        username = args?.getString(DetailUserActivity.EXTRA_USERNAME).toString()

        _binding = FragmentFollowBinding.bind(view)

        adapter = UserAdapter()
        adapter.notifyDataSetChanged()

        binding.apply {
            rvFollowers.setHasFixedSize(true)
            rvFollowers.layoutManager = LinearLayoutManager(activity)
            rvFollowers.adapter = adapter
        }
        showLoading(true)

        if (fragmentPostion != null) {
            fragment(fragmentPostion)
        }
    }

    private fun fragment(fragment: Int) {
        when (fragment) {
            0 -> setFollowersFragment()
            1 -> setFollowingFragment()
        }
    }

    private fun setFollowingFragment() {

        val viewModel: FollowingViewModel =
            ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
                FollowingViewModel::class.java
            )
        viewModel.setListFollowing(username, mContext)
        viewModel.getListFollowing().observe(viewLifecycleOwner, {
            if (it != null) {
                adapter.setList(it)
                showLoading(false)
            }
        })
    }

    private fun setFollowersFragment() {

        val viewModel: FollowersViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        ).get(FollowersViewModel::class.java)
        viewModel.setListFollowers(username, mContext)
        viewModel.getListFollowers().observe(viewLifecycleOwner, {
            if (it != null) {
                adapter.setList(it)
                showLoading(false)
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }
}