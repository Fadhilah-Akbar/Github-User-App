package com.project.githubuserapps

import android.annotation.SuppressLint
import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.project.githubuserapps.adapter.SectionPagerAdapter
import com.project.githubuserapps.data.model.UserModel
import com.project.githubuserapps.data.viewmodel.DetailUserViewModel
import com.project.githubuserapps.databinding.ActivityDetailUserBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DetailUserActivity : AppCompatActivity() {

    companion object {
        const val EXTRAS_DATA = "EXTRA_DATA"
        const val EXTRA_USERNAME = "EXTRA_USERNAME"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_1,
            R.string.tab_2
        )

    }

    private lateinit var binding: ActivityDetailUserBinding
    private lateinit var viewModel: DetailUserViewModel
    var progress: ProgressDialog? = null

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val data = intent.getParcelableExtra<UserModel>(EXTRAS_DATA) as UserModel
        val bundle = Bundle()
        bundle.putString(EXTRA_USERNAME, data.login)

        supportActionBar?.title = data.login

        progress = ProgressDialog(this@DetailUserActivity)
        progress?.setMessage(getString(R.string.load))
        progress?.show()

        viewModel = ViewModelProvider(this).get(DetailUserViewModel::class.java)

        viewModel.setUserDetail(data.login,applicationContext)

        viewModel.getUserDetail().observe(this, {
            if (it != null) {
                binding.apply {
                    tvNameDetail.text = it.name
                    tvUsernameDetail.text = it.login
                    tvLocationDetail.text = it.location
                    tvFollowers.text = "  ${it.followers} Followers"
                    tvFollowing.text = "  ${it.following} Following"
                    Glide.with(this@DetailUserActivity)
                        .load(it.avatar_url)
                        .into(ciGithubUserImageDetail)
                }
            }
            progress?.dismiss()
        })

        var _isCheck = false
        CoroutineScope(Dispatchers.IO).launch {
            val count = viewModel.checkUser(data.id)
            withContext(Dispatchers.Main) {
                if (count != null) {
                    if (count > 0) {
                        binding.toggleButton.isChecked = true
                        _isCheck = true
                    } else {
                        binding.toggleButton.isChecked = false
                        _isCheck = false
                    }
                }
            }
        }

        binding.toggleButton.setOnClickListener {
            _isCheck = !_isCheck
            if (_isCheck) {
                viewModel.addToFavorite(data.login, data.id, data.avatar_url, data.html_url)
            } else {
                viewModel.removeFavoriteUser(data.id)
            }
            binding.toggleButton.isChecked = _isCheck

        }

        val sectionPagerAdapter = SectionPagerAdapter(this, this, bundle)
        val viewPager: ViewPager2 = binding.viewPagerDetail
        viewPager.adapter = sectionPagerAdapter
        val tabs: TabLayout = binding.tabsDetail
        TabLayoutMediator(tabs, viewPager){ tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        supportActionBar?.elevation = 0f

    }
}