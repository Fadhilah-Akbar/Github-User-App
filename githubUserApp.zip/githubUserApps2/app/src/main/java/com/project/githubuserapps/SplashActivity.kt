package com.project.githubuserapps

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SplashActivity : AppCompatActivity() {

    private val SPLASH_RUN_TIME: Long = 3000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        supportActionBar!!.hide()

        val thread: Thread = object : Thread() {
            override fun run() {
                try {
                    sleep(SPLASH_RUN_TIME)
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                } finally {
                    startActivity(Intent(applicationContext, MainActivity::class.java))
                    finish()
                }
            }
        }
        thread.start()

    }
}