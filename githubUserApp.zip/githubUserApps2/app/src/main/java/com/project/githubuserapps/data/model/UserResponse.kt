package com.project.githubuserapps.data.model

data class UserResponse(
    val items: ArrayList<UserModel>
)