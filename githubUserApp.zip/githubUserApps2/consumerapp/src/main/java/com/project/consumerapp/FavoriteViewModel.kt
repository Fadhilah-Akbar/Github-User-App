package com.project.consumerapp

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class FavoriteViewModel(application: Application) : AndroidViewModel(application) {
    private var list = MutableLiveData<ArrayList<UserModel>>()

    @SuppressLint("Recycle")
    fun setFavoriteUser(context: Context) {
        val cursor = context.contentResolver.query(
            DatabaseContact.FavoriteUserColumns.CONTENT_URI,
            null,
            null,
            null,
            null
        )
        val listConvert = MappingHelper.mapCursorToArrayList(cursor)
        list.postValue(listConvert)
    }

    fun getFavoriteUser(): LiveData<ArrayList<UserModel>> {
        return list
    }
}