package com.project.consumerapp

data class UserModel(
    val login: String,
    val id: Int,
    val avatar_url: String,
    val html_url: String
)
