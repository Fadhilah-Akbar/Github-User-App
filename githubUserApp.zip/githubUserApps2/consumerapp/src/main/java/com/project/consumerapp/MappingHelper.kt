package com.project.consumerapp

import android.database.Cursor

object MappingHelper {
    fun mapCursorToArrayList(cursor: Cursor?): ArrayList<UserModel> {
        val list = ArrayList<UserModel>()
        if (cursor != null) {
            while (cursor.moveToNext()) {
                val id =
                    cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseContact.FavoriteUserColumns.ID))
                val username =
                    cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContact.FavoriteUserColumns.USERNAME))
                val avatarUrl =
                    cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContact.FavoriteUserColumns.AVATAR_URL))
                val htmlUrl =
                    cursor.getString(cursor.getColumnIndexOrThrow(DatabaseContact.FavoriteUserColumns.HTML_URL))
                list.add(
                    UserModel(
                        username,
                        id,
                        avatarUrl,
                        htmlUrl
                    )
                )
            }
        }
        return list
    }
}